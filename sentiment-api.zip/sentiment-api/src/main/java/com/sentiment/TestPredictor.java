package com.sentiment;

public class TestPredictor {

    public static void main(String[] args) throws Exception {

        SentimentPredictor predictor =
                new SentimentPredictor("models/pipeline.onnx");

        Prediction p = predictor.predict(
                "ME aburri con esta pelicula, no entiendo por qué la elogian tanto."
        );

        System.out.println(p);

        predictor.close();
    }
}
