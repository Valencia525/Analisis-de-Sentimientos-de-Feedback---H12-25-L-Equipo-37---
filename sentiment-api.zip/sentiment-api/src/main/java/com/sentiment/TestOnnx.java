package com.sentiment;
import com.sentiment.preprocess.Preprocessor;
import com.sentiment.rules.SentimentWeights;

public class TestOnnx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String raw = "La sucursal cuenta con estacionamiento y es muy buena";
		String clean = Preprocessor.preprocessText(raw, SentimentWeights.WEIGHTS.keySet());

		System.out.println(clean);
	}

}
