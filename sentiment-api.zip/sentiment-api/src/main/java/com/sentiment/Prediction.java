package com.sentiment;

public class Prediction {

    public final String label;
    public final double probOriginal;
    public final double probAdjusted;
    public final String cleanText;

    public Prediction(
            String label,
            double probOriginal,
            double probAdjusted,
            String cleanText
    ) {
        this.label = label;
        this.probOriginal = probOriginal;
        this.probAdjusted = probAdjusted;
        this.cleanText = cleanText;
    }

    @Override
    public String toString() {
        return "Prediction{" +
                "label='" + label + '\'' +
                ", probOriginal=" + probOriginal +
                ", probAdjusted=" + probAdjusted +
                ", cleanText='" + cleanText + '\'' +
                '}';
    }
}
