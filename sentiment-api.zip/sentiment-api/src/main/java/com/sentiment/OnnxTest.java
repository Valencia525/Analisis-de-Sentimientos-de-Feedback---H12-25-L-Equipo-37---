package com.sentiment;

import ai.onnxruntime.*;
import com.sentiment.preprocess.Preprocessor;
import com.sentiment.rules.SentimentWeights;
import com.sentiment.rules.ProbabilityAdjuster;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OnnxTest {

    public static void main(String[] args) throws Exception {

    	String raw = "La sucursal cuenta con estacionamiento y es muy buena";

    	// 1️⃣ Preprocesar
    	String clean = Preprocessor.preprocessText(
    	        raw,
    	        SentimentWeights.WEIGHTS.keySet()
    	);

    	// 2️⃣ Simular probabilidad ONNX
    	double probModel = 0.55;

    	// 3️⃣ Ajustar
    	double probAdj = ProbabilityAdjuster.adjust(clean, probModel);

    	System.out.println("Texto limpio: " + clean);
    	System.out.println("Prob modelo: " + probModel);
    	System.out.println("Prob ajustada: " + probAdj);
    }
}
