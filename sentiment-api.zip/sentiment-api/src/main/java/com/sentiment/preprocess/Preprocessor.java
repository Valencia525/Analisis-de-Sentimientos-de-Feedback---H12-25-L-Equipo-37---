package com.sentiment.preprocess;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.Pattern;

public class Preprocessor {

    // === STOPWORDS (puedes ampliar luego) ===
    private static final Set<String> STOPWORDS = Set.of(
        "y","en","de","para","con","el","la","los","las","un","una",
        "simplemente","tambien","minutos","supone","dvd","gran",
        "definitivamente","hoy","siempre","especialmente","siquiera",
        "pobre","menos","dinero","guion","creo","actuaciones",
        "perfectamente","corazon","intento","absoluto","parece"
    );

    // === NORMALIZACIÓN DE FRASES ===
    private static final Map<String, String> PHRASE_REPLACEMENTS = Map.ofEntries(
        Map.entry("no lo recomiendo", "no_recomiendo"),
        Map.entry("no la recomiendo", "no_recomiendo"),
        Map.entry("no recomiendo", "no_recomiendo"),
        Map.entry("muy buena", "muy_buena"),
        Map.entry("muy bueno", "muy_bueno"),
        Map.entry("es buena", "es_buena"),
        Map.entry("es bueno", "es_bueno"),
        Map.entry("realmente bueno", "realmente_bueno"),
        Map.entry("realmente buena", "realmente_buena"),
        Map.entry("muy bien", "muy_bien"),
        Map.entry("realmente bien", "realmente_bien"),
        Map.entry("buen producto", "buen_producto"),
        Map.entry("vale la pena", "vale_la_pena"),
        Map.entry("no funciona", "no_funciona"),
        Map.entry("no sirve", "no_sirve"),
        Map.entry("llego tarde", "llego_tarde"),
        Map.entry("llego roto", "producto_danado"),
        Map.entry("esperaba mas", "esperaba_mas"),
        Map.entry("ni bueno ni malo", "ni_bueno_ni_malo"),
        Map.entry("no volveria", "no_volveria")
    );

    private static final Pattern NON_WORD = Pattern.compile("[^\\w\\s_]");
    private static final Pattern MULTI_SPACE = Pattern.compile("\\s+");
    private static final Pattern DIGITS = Pattern.compile("\\d+");

    public static String preprocessText(String text, Set<String> sentimentKeys) {

        if (text == null || text.isBlank()) return "";

        // 1️⃣ lowercase
        text = text.toLowerCase();

        // 2️⃣ quitar acentos
        text = Normalizer.normalize(text, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");

        // 3️⃣ quitar números
        text = DIGITS.matcher(text).replaceAll("");

        // 4️⃣ normalizar frases
        for (Map.Entry<String, String> e : PHRASE_REPLACEMENTS.entrySet()) {
            text = text.replace(e.getKey(), e.getValue());
        }

        // 5️⃣ quitar puntuación (mantener _)
        text = NON_WORD.matcher(text).replaceAll("");

        // 6️⃣ espacios extra
        text = MULTI_SPACE.matcher(text).replaceAll(" ").trim();

        // 7️⃣ tokenizar + filtrar
        List<String> cleaned = new ArrayList<>();

        for (String word : text.split(" ")) {
            if (sentimentKeys.contains(word)) {
                cleaned.add(word);
            } else if (!STOPWORDS.contains(word) && word.length() > 2) {
                cleaned.add(word);
            }
        }

        return String.join(" ", cleaned);
    }
}
