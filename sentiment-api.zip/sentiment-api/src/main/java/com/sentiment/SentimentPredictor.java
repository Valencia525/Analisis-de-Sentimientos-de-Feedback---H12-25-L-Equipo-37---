package com.sentiment;

import ai.onnxruntime.*;

import com.sentiment.preprocess.Preprocessor;
import com.sentiment.rules.ProbabilityAdjuster;
import com.sentiment.rules.SentimentWeights;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SentimentPredictor {

    private final OrtEnvironment env;
    private final OrtSession session;
    private final String inputName;

    public SentimentPredictor(String modelPath) throws OrtException {

        this.env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions options = new OrtSession.SessionOptions();

        this.session = env.createSession(
                Paths.get(modelPath).toString(),
                options
        );

        // Tomamos el nombre real del input del modelo
        this.inputName = session.getInputNames().iterator().next();
    }

    /**
     * Predicción FINAL de sentimiento.
     */
    public Prediction predict(String rawText) throws OrtException {

        // 1️⃣ Preprocesar texto
        String cleanText = Preprocessor.preprocessText(
                rawText,
                SentimentWeights.WEIGHTS.keySet()
        );

        // 2️⃣ Crear tensor ONNX (batch = 1)
        String[][] input = new String[][]{{ cleanText }};
        OnnxTensor inputTensor = OnnxTensor.createTensor(env, input);

        Map<String, OnnxTensor> inputs = new HashMap<>();
        inputs.put(inputName, inputTensor);

        // 3️⃣ Inferencia ONNX
        OrtSession.Result result = session.run(inputs);

        // Output 0: etiqueta predicha por el modelo
        long[] labels = (long[]) result.get(0).getValue();

        // Output 1: probabilidades
        @SuppressWarnings("unchecked")
        List<OnnxMap> probList = (List<OnnxMap>) result.get(1).getValue();

        OnnxMap probMap = probList.get(0);

        @SuppressWarnings("unchecked")
        Map<Long, Float> probs = (Map<Long, Float>) probMap.getValue();

        double probNeg = probs.getOrDefault(0L, 0f);
        double probPos = probs.getOrDefault(1L, 0f);

        // 4️⃣ Ajuste por reglas semánticas
        double probAdj = ProbabilityAdjuster.adjust(cleanText, probPos);

        // 5️⃣ Decisión final
        String label;
        if (probAdj >= 0.70) {
            label = "Positivo";
        } else if (probAdj <= 0.30) {
            label = "Negativo";
        } else {
            label = "Neutral";
        }

        // 6️⃣ Limpiar recursos
        result.close();
        inputTensor.close();

        return new Prediction(
                label,
                probPos,
                probAdj,
                cleanText
        );
    }

    public void close() throws OrtException {
        session.close();
        env.close();
    }
}
