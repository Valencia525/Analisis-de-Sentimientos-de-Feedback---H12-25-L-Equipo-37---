package com.sentiment.rules;

import java.util.Map;

public class SentimentWeights {

    // Escala: +1.5 (Excelente) a -1.5 (Pésimo)
    public static final Map<String, Double> WEIGHTS = Map.ofEntries(

        // =========================
        // POSITIVOS (Fuertes y Moderados)
        // =========================
        Map.entry("excelente", 1.5),
        Map.entry("perfecto", 1.5),
        Map.entry("increible", 1.4),
        Map.entry("fantastico", 1.4),
        Map.entry("maravilloso", 1.4),
        Map.entry("totalmente_recomendado", 1.5),
        Map.entry("recomiendo_totalmente", 1.5),
        Map.entry("supero_expectativas", 1.5),
        Map.entry("muy_satisfecho", 1.3),
        Map.entry("todo_perfecto", 1.5),
        Map.entry("mejor", 0.7),
        Map.entry("recomiendo", 0.8),
        Map.entry("genial", 0.9),
        Map.entry("gusto", 0.6),
        Map.entry("bonito", 0.7),
        Map.entry("util", 0.7),
        Map.entry("recomendable", 0.8),
        Map.entry("funciona_bien", 0.9),
        Map.entry("buen_producto", 0.8),
        Map.entry("vale_la_pena", 1.0),
        Map.entry("cinco_estrellas", 1.3),
        Map.entry("comodo", 0.7),
        Map.entry("rapido", 0.6),
        Map.entry("muy_bueno", 0.8),
        Map.entry("muy_buena", 0.8),
        Map.entry("es_bueno", 0.5),
        Map.entry("es_buena", 0.5),
        Map.entry("realmente_buena", 0.9),
        Map.entry("realmente_bueno", 0.9),
        Map.entry("muy_bien", 0.6),
        Map.entry("realmente_bien", 0.9),

        // =========================
        // NEGATIVOS (Fuertes y Moderados)
        // =========================
        Map.entry("pesimo", -1.5),
        Map.entry("pesimos", -1.5),
        Map.entry("horrible", -1.5),
        Map.entry("terrible", -1.5),
        Map.entry("estafa", -1.5),
        Map.entry("fraude", -1.5),
        Map.entry("no_sirve", -1.4),
        Map.entry("peor", -1.3),
        Map.entry("basura", -1.4),
        Map.entry("desastre", -1.3),
        Map.entry("no_recomiendo", -1.3),
        Map.entry("perdida_dinero", -1.4),
        Map.entry("problema", -0.6),
        Map.entry("mal", -0.7),
        Map.entry("roto", -1.0),
        Map.entry("mala", -0.7),
        Map.entry("caro", -0.6),
        Map.entry("mala_calidad", -0.9),
        Map.entry("decepcion", -1.0),
        Map.entry("no_funciona", -1.1),
        Map.entry("defectuoso", -1.0),
        Map.entry("fallas", -0.8),
        Map.entry("producto_danado", -1.2),
        Map.entry("llego_tarde", -0.7),
        Map.entry("no_volveria", -1.1),

        // =========================
        // NEUTRALES / DÉBILES
        // =========================
        Map.entry("regular", 0.0),
        Map.entry("promedio", 0.0),
        Map.entry("aceptable", 0.1),
        Map.entry("normal", 0.0),
        Map.entry("parece", 0.0),
        Map.entry("correcto", 0.1),
        Map.entry("sirve", 0.1),
        Map.entry("uso", 0.0),
        Map.entry("funcional", 0.1),
        Map.entry("esperaba_mas", -0.3),
        Map.entry("nada_especial", -0.2),
        Map.entry("ni_bueno_ni_malo", 0.0),
        Map.entry("pasable", 0.0),
        Map.entry("ok", 0.1),
        Map.entry("bien", 0.0),
        Map.entry("buena", 0.0),
        Map.entry("bueno", 0.0),
        Map.entry("original", 0.0)
    );

    private SentimentWeights() {
        // Evita instanciación
    }
}
