package com.sentiment.rules;

import java.util.Map;

public class ProbabilityAdjuster {

    /**
     * Ajusta la probabilidad positiva usando pesos semánticos.
     *
     * @param cleanText texto YA preprocesado (salida de Preprocessor)
     * @param probPos   probabilidad positiva del modelo ONNX (0–1)
     * @param alpha     cuánto influyen las reglas (recomendado: 0.15)
     * @return probabilidad ajustada (clamp 0.01–0.99)
     */
    public static double adjust(String cleanText, double probPos, double alpha) {

        double score = 0.0;

        // 1️⃣ Sumar pesos semánticos
        for (String word : cleanText.split(" ")) {
            score += SentimentWeights.WEIGHTS.getOrDefault(word, 0.0);
        }

        // 2️⃣ Clamp del score (igual que en Python)
        score = Math.max(Math.min(score, 2.0), -2.0);

        // 3️⃣ Ajuste suave
        double adjustedProb = probPos + alpha * score;

        // 4️⃣ Clamp final de probabilidad
        adjustedProb = Math.max(Math.min(adjustedProb, 0.99), 0.01);

        return adjustedProb;
    }

    // Overload con alpha por defecto (0.15)
    public static double adjust(String cleanText, double probPos) {
        return adjust(cleanText, probPos, 0.15);
    }

    private ProbabilityAdjuster() {
        // Evita instanciación
    }
}
